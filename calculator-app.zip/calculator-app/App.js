import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet
} from 'react-native';

function App() {
  const [number1, setNumber1] = useState('');
  const [number2, setNumber2] = useState('');
  const [answer, setAnswer] = useState(null);

  const handleAddition = () => {
    let ans = Number(number1) + Number(number2);
    setAnswer(ans);
  };

  const handleSubtraction = () => {
    let ans = Number(number1) - Number(number2);
    setAnswer(ans);
  };

  const handleMultiplication = () => {
    let ans = Number(number1) * Number(number2);
    setAnswer(ans);
  };

  const handleDivision = () => {
    let ans = Number(number1) / Number(number2);
    setAnswer(ans);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Calculator</Text>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          placeholder="Enter first number"
          value={number1}
          onChangeText={setNumber1}
        />
        <TextInput
          style={styles.input}
          keyboardType="numeric"
          placeholder="Enter second number"
          value={number2}
          onChangeText={setNumber2}
        />
      </View>
      <View style={styles.operatorContainer}>
        <TouchableOpacity
          style={styles.button}
          onPress={handleAddition}
        >
          <Text style={styles.buttonText}>Add</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={handleSubtraction}
        >
          <Text style={styles.buttonText}>Subtract</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={handleMultiplication}
        >
          <Text style={styles.buttonText}>Multiply</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={handleDivision}
        >
          <Text style={styles.buttonText}>Divide</Text>
        </TouchableOpacity>
      </View>
      {answer !== null && (
        <View style={styles.answerContainer}>
          <Text style={styles.answerText}>Answer: {answer}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  heading: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  inputContainer: {
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  operatorContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    width: '22%',
    height: 40,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  answerContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  answerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
});

export default App;
